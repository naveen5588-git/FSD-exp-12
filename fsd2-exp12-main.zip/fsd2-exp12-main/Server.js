require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

const PORT = process.env.PORT || 5002;


// Middleware
app.use(cors());
app.use(express.json());


// MongoDB Connection
mongoose
    .connect(process.env.MONGO_URI)
    .then(() => {
        console.log("MongoDB connected successfully");
    })
    .catch((err) => {
        console.error("MongoDB connection error:", err);
    });


// Routes
const taskRoutes = require("./routes/tasks");

app.use("/api/tasks", taskRoutes);


// Home route
app.get("/", (req, res) => {
    res.send("Welcome to the To-Do List API!");
});


// Start Server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});